window.ENV_CONFIG = {
  // 支付宝用户ID
  VITE_ALIPAY_USER_ID: "2088922557117308",
  // 赏金二维码token
  VITE_QR_TOKEN: "AhGZ19610515y4vfkzko7jotd85w2O"
};

// 作者：羚羊公子
// 配置文档：https://lygzblog.feishu.cn/wiki/HlcQw1Za1i2Gnek8ToycVbM2nbe?from=from_copylink

